# DIS21a.1

This repo contains necessary scripts and all the exercises of course DIS21a.1 !
